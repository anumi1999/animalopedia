            //var batch = localStorage.getItem('batch');
            //console.log(batch);
            var fb_db = firebase.database().ref("users/" + uid)
            var i = 1;
            var n;
            fb_db.child("/question_paper/").on('value', function(snapshot) {
                            console.log('question_paper');
                              snapshot.forEach(function(childSnapshot) {
                                  console.log('called');
                                var childKey = childSnapshot.key;
                                var childData = childSnapshot.val();
                                console.log('called',childData);
                                $("ul").append("<li class = 'content'>" + childKey + "</li>"); 
                              }); 
                              var col = document.getElementsByClassName("content");
                                    console.log(col.length);
                                    var i;
                                    var content;
                                   for (i = 0 ; i < col.length; i++) {
                                        col[i].addEventListener("click", function() {
                                        content = this.textContent;
                                        console.log("this is content" , content);
                                        console.log('1', content);
                                        localStorage.setItem('batch' , content);
                                        window.location.href = "records1.html";
                                    });
                                    } 
                        });
    